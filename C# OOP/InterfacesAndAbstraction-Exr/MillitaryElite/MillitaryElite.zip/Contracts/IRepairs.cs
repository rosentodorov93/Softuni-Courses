﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MillitaryElite.Contracts
{
    public interface IRepairs
    {
        public string PartName { get;}
        public int WorkedHours { get;}
    }
}
