﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MillitaryElite.Enums
{
    public enum State
    {
        inProgress =1,
        Finished =2
    }
}
